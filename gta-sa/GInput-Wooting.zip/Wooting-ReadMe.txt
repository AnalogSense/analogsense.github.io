GInputSA Wooting
Wooting CODE IT Build
Last update - 21.10.2018


ATTENTION: This package contains an EARLY version of GInput for San Andreas supporting Wooting keyboards.
	As of now, it may be NOT complete. It is planned to appear for GTA III and Vice City at a later point.
	Current build has been created as a proof of concept for Wooting CODE IT contest.


DESCRIPTION

	Who said GInput has to work only with gamepads? Wooting is a keyboard with full RGB LED control
	and analog keys - sounds like a perfect fit to support natively in GTA III, Vice City
	and San Andreas via GInput!

	This package contains an early version of said integration, featuring:

	* Full support for analog keys
	* Backlight reflecting gang activity in the area you are in
	* Function keys flash when the police is after you
	* Keyboard dims when the player is hidden in the shadows
	* During dancing minigames, relevant keys reflect your score while all the other keys are dimmed

	If the project picks up, more Wooting specific features will be needed!

INSTALLATION

	First and foremost, GInput for San Andreas works ONLY with a 1.0 version of the game.
	If you are using a Steam version, you need to downgrade.
	Refer to this page for a download link, installation instructions and a brief explanation
	on why downgrading San Andreas is a very good idea:

	https://gtaforums.com/topic/753764-san-andreas-downgrader/

	Once the game is downgraded to 1.0, just extract this archive to the game directory,
	overwriting any existing files. If done correctly, your Wooting keyboard should
	be natively supported right away!
